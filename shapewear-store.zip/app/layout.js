
export const metadata = { title: "Shapewear Store" };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "sans-serif", margin: 0, padding: 20 }}>
        <h2>Shapewear Store</h2>
        {children}
      </body>
    </html>
  );
}
