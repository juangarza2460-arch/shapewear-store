
import Link from "next/link";

const products = [
  { id: 1, name: "High‑Waist Body Shaper", price: 49.99 },
  { id: 2, name: "Tummy Control Bodysuit", price: 59.99 },
  { id: 3, name: "Waist Trainer Corset", price: 39.99 }
];

export default function Shop() {
  return (
    <div>
      <h2>Products</h2>
      <ul>
        {products.map(p => (
          <li key={p.id}>
            {p.name} – ${p.price}
            <Link href={"/checkout?product=" + p.id} style={{ marginLeft: 10 }}>
              Buy
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
