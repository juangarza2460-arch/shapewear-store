
import Link from "next/link";

export default function Home() {
  return (
    <div>
      <h3>Welcome to the store</h3>
      <Link href="/shop">Go to Shop</Link>
    </div>
  );
}
