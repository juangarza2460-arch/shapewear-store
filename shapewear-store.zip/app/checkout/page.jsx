
"use client";
import { useSearchParams } from "next/navigation";

export default function Checkout() {
  const searchParams = useSearchParams();
  const product = searchParams.get("product");
  return <div>Checkout placeholder for product #{product}</div>;
}
